import java.sql.*;
public class DB_Connection {
	public static void main(String[] args) throws Exception {
		String url = "jdbc:mysql://localhost:3306/artha_school";
		String uname = "root";
		String pass = "**Madhwa32**";
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection(url,uname,pass);
		Statement st = conn.createStatement();
		ArthaCRUD ac = new ArthaCRUD();
		ac.crud(st);
		conn.close();
		}
}