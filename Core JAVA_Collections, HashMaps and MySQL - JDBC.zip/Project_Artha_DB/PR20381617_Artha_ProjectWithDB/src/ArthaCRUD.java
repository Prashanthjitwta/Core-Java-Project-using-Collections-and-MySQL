import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

public class ArthaCRUD {
	public void crud(Statement st) throws SQLException {
		Scanner sc = new Scanner(System.in);
		Scanner sc1 = new Scanner(System.in);

		ArrayList<Integer> test = new ArrayList<Integer>();
		ArrayList<Integer> quiz = new ArrayList<Integer>();
		ArrayList<Integer> lab = new ArrayList<Integer>();
		ArrayList<Integer> project = new ArrayList<Integer>();
		ArrayList<Integer> test1 = new ArrayList<Integer>();
		ArrayList<Integer> quiz1 = new ArrayList<Integer>();
		ArrayList<Integer> lab1 = new ArrayList<Integer>();
		ArrayList<Integer> project1 = new ArrayList<Integer>();
		String[] subs = new String[] {"Electro Fields","Computing Techniques"};

		
		String snam = "";
		String subject = "";
		int sID = 0;
		int ch;
		do {
			System.out.println("Select any option to continue");
			System.out.println("1. Enroll new student ");
			System.out.println("2. Display all student details ");
			System.out.println("3. Search for a student ");
			System.out.println("4. Update student details ");
			System.out.println("5. Delete student details ");
			System.out.println("6. Delete all details");

			System.out.println("0. To exit the application");
			int update = 0;
			int sid = 0;
			ch = sc.nextInt();
			switch(ch) {
			case 1:
				int status = 0;
				System.out.print("Enter student ID: ");
				sID = sc.nextInt();
				status = checkEnrollmentID(sID,status,st);
				ResultSet ra = st.executeQuery("select * from student");
				if(status == 1 || ra.next() == false) {
					System.out.print("Enter student name: ");
					snam = sc1.nextLine();
					EnrollNewStudent(status,st,snam, sc,sc1, test, quiz, lab, project,subject,
							test1, quiz1, lab1, project1,status,update);
					calculateScoreSub1(sID,snam,subject,test, quiz, lab,project,st,update,sid);
					calculateScoreSub2(sID,snam,subject,test1, quiz1, lab1, project1,st,update,sid);
				}
				else {
					System.out.println("");
					System.out.println("Student ID already exists with ID "+sID+" ...!");
			}
				break;

			case 2:
				System.out.println("----------------------------------------------------------------");
				System.out.println("ID | Name | Subject | Test | Quiz | Lab | Project | Percentage");
				System.out.println("----------------------------------------------------------------");
				displayCollection(st);
				System.out.println("----------------------------------------------------------------");
				break;
				
			case 3:
				System.out.println("1. Search a student by ID ");
				System.out.println("2. Search students details by Subject ");
				int opt = sc.nextInt();
				switch(opt) {
					case 1:
						status = 0;
						System.out.print("Enter student ID : ");   
						int stuID = sc.nextInt();
						int status1 = checkEnrollmentID(stuID, status, st);
						if(status1 == 0) {
							searchByID(st,stuID);
						}
						ResultSet r = st.executeQuery("select * from student");
						if(status1 == 1 || r.next() == false) {
							System.out.println("Record Not Found..!");
							System.out.println("");
						}
						break;
					case 2:
						System.out.print("Enter Subject Name : ");   
						String subNam = sc1.nextLine();
						if(subNam.equalsIgnoreCase(subs[0]) || subNam.equalsIgnoreCase(subs[1])) {
							searchBySubject(st,subNam);
						}
						else {
							System.out.println("Record not found...!");
							System.out.println("");
						}
						break; 
				}
				break;
				
			case 4:
				System.out.println("Enter ID to be updated");
				sid = sc.nextInt();
				status = 0;
				update =1;
				status = checkEnrollmentID(sid,status,st);
				ResultSet rset = st.executeQuery("select * from student");
				if(status == 0) {
					System.out.print("Enter student name: ");
					snam = sc1.nextLine();
					EnrollNewStudent(status,st,snam, sc,sc1, test, quiz, lab, project,subject,
							test1, quiz1, lab1, project1,sid, update);
					
					
				}
				else {
					System.out.println("");
					System.out.println("Student ID does not exist with ID "+sID+" ...!");
				}
				break;
				
			case 5:
				status = 0;
				System.out.print("Enter student ID : ");   
				int stuID = sc.nextInt();
				int status1 = checkEnrollmentID(stuID, status, st);
				if(status1 == 0) {
					deleteByID(st,stuID);
					System.out.println("Record with ID "+stuID+" Deleted !");
					System.out.println("");
				}
				ResultSet r = st.executeQuery("select * from student");
				if(status1 == 1 || r.next() == false) {
					System.out.println("Record Not Found..!");
					System.out.println("");
				}
				break;
			case 6:
				System.out.println("Are you sure to delete all details..press 1 to delete 0 to exit");
				int conform = sc.nextInt(); 
				if(conform == 1) {
					deleteAll(st);
				}
				else {
					break;
				}
				break;
			case 0:
				System.out.println("Exiting....  ||  Thank You...!");
				sc.close();
				sc1.close();
				st.close();
				System.exit(0);
				
				break;
			default:
				System.out.println("You Selected Wrong Option. Select Any from List.");
				System.out.println("");
			}
		}while(ch!= 0);
		
		
	}

	private void EnrollNewStudent(int status, Statement st, String snam, Scanner sc,
		Scanner sc1, ArrayList<Integer> test, ArrayList<Integer> quiz, ArrayList<Integer> lab,
		ArrayList<Integer> project, String subject, ArrayList<Integer> test1, ArrayList<Integer> 
		quiz1, ArrayList<Integer> lab1, ArrayList<Integer> project1, int sid, int update) throws SQLException {
		
		int sub;
		test.clear();test1.clear();
		quiz.clear();quiz1.clear();
		lab.clear();lab1.clear();
		project.clear();project1.clear();
		do {
			System.out.println("Choose the subject");
			System.out.println("1. Electro Fields");
			System.out.println("2. Computing Techniques");
			int opt = sc.nextInt();
			if(update == 0) {
			switch(opt) 
			{
				case 1:
					subject = "Electro Fields";
					subject(snam, sc, test, quiz, lab, project,subject,
							test1, quiz1, lab1, project1);
					break;
				case 2:
					subject = "Computing Techniques";
					subject(snam, sc, test, quiz, lab, project,subject,
							test1, quiz1, lab1, project1);
					break;
			}
			}
			if(update == 1) {
				int a = 0;
				switch(opt) 
				{
					case 1:
						
						subject = "Electro Fields";
						subject(snam, sc, test, quiz, lab, project,subject,
								test1, quiz1, lab1, project1);
						calculateScoreSub1(a,snam,subject,test, quiz, lab,project,st,update,sid);

						break;
					case 2:
						subject = "Computing Techniques";
						subject(snam, sc, test, quiz, lab, project,subject,
								test1, quiz1, lab1, project1);
						calculateScoreSub2(a,snam,subject,test1, quiz1, lab1, project1,st,update,sid);

						break;
				}
			}
			System.out.println("1. To continue with subjects or 0. To exit subjects ");
			sub = sc.nextInt();
		}while(sub!=0);
		
	}
	

	private static int checkEnrollmentID(int sID, int status, Statement st) throws SQLException {
		String checkIdQuery = "select id from student";
		ResultSet rs = st.executeQuery(checkIdQuery);
		while(rs.next()) {
			int id = rs.getInt(1);
			if(id == sID) {
				status = 0;
				break;
		}
			else {
				status = 1;
			}
		}
		return status;
	}

	//Subject rating input and assignment category
	public static void subject(String snam, Scanner sc, ArrayList<Integer> test, ArrayList<Integer> quiz,
			ArrayList<Integer> lab, ArrayList<Integer> project, String subject, ArrayList<Integer> test1,
			ArrayList<Integer> quiz1, ArrayList<Integer> lab1, ArrayList<Integer> project1) {
		
		if(subject == "Electro Fields") {
			System.out.print("Enter "+snam+"'s rating in "+subject+" Test : " );
			test.add(sc.nextInt());
			System.out.print("Enter "+snam+"'s rating in "+subject+" Quiz : " );
			quiz.add(sc.nextInt());
			System.out.print("Enter "+snam+"'s rating in "+subject+" Lab : " );
			lab.add(sc.nextInt());
			System.out.print("Enter "+snam+"'s rating in "+subject+" Project : " );
			project.add(sc.nextInt());
		}
		if(subject == "Computing Techniques") {
			System.out.print("Enter "+snam+"'s rating in "+subject+" Test : " );
			test1.add(sc.nextInt());
			System.out.print("Enter "+snam+"'s rating in "+subject+" Quiz : " );
			quiz1.add(sc.nextInt());
			System.out.print("Enter "+snam+"'s rating in "+subject+" Lab : " );
			lab1.add(sc.nextInt());
			System.out.print("Enter "+snam+"'s rating in "+subject+" Project : " );
			project1.add(sc.nextInt());
			}
	}
	
//FOR SUBJECT 1
	public static void calculateScoreSub1(int sID, String snam, String subject, ArrayList<Integer> test1, 
			ArrayList<Integer> quiz1,ArrayList<Integer> lab1, ArrayList<Integer> project1, Statement st, int update, int sid) throws SQLException {
		int Testweights = 40;
		int Quizweights = 20;
		int Labweights = 10;
		int Projectweights = 30;
		
		float[] tot1 = new float[test1.size()];
		float[] tot2 = new float[quiz1.size()];
		float[] tot3 = new float[lab1.size()];
		float[] tot4 = new float[project1.size()];
		float[] overallRating = new float[10];
		int j = 0;
		float percentage = 0;
		
		//Test Score
		int TestscoreSize = test1.size();
		for(int i=0; i<TestscoreSize; i++) {
			int marks = test1.get(i);
			tot1[i] = (Testweights/TestscoreSize)*marks;
		}
		float Testsum = 0;
		for(int k=0; k<tot1.length;k++) {
			Testsum = Testsum + tot1[k];
		}
		float testFinalSum = Testsum/100;
		overallRating[j] = testFinalSum;
		j++;
		
		//Quiz Score
		int quizscoreSize = quiz1.size();
		for(int i=0; i<quizscoreSize; i++) {
			int marks = quiz1.get(i);
			tot2[i] = (Quizweights/quizscoreSize)*marks;
		}
		float quizsum = 0;
		for(int k=0; k<tot2.length;k++) {
			quizsum = quizsum + tot2[k];
		}
		float quizFinalSum = quizsum/100;
		overallRating[j] = quizFinalSum;
		j++;

		//Lab Score
		int labscoreSize = lab1.size();
		for(int i=0; i<labscoreSize; i++) {
			int marks = lab1.get(i);
			tot3[i] = (Labweights/labscoreSize)*marks;
		}
		float labsum = 0;
		for(int k=0; k<tot3.length;k++) {
			labsum = labsum + tot3[k];
		}
		float labFinalSum = labsum/100;
		overallRating[j] = labFinalSum;
		j++;
		
		//Project Score
		int projectscoreSize = project1.size();
		for(int i=0; i<projectscoreSize; i++) {
			int marks = project1.get(i);
			tot4[i] = (Projectweights/projectscoreSize)*marks;
		}
		float projectsum = 0;
		for(int k=0; k<tot4.length;k++) {
			projectsum = projectsum + tot4[k];
		}
		float projectFinalSum = projectsum/100;
		overallRating[j] = projectFinalSum;
		j++;
		
		subject = "Electro Fields";
		
		percentage = calOverAll(overallRating);
		
		if(update == 0 && sid == 0) {
			String insertQuery = "insert into student(id,name,subject,Ttest,Tquiz,Tlab,Tproject,percentage) values ("+sID+",'"+snam+"','"+subject+"',"+testFinalSum+","+quizFinalSum+","+labFinalSum+","+projectFinalSum+","+percentage+")";
			st.executeUpdate(insertQuery);
		}
		if(update == 1) {
			String updateQuery = "update student set name = '"+snam+"', Ttest = "+testFinalSum+",Tquiz = "+quizFinalSum+",Tlab = "+labFinalSum+", "
					+ "Tproject = "+quizFinalSum+",percentage = "+percentage+" WHERE id = "+sid+" and subject = 'Electro Fields'";
			st.executeUpdate(updateQuery);
		}
	}

//FOR SUBJECT 2
	public static void calculateScoreSub2(int sID, String snam, String subject, ArrayList<Integer> test, 
			ArrayList<Integer> quiz,ArrayList<Integer> lab, ArrayList<Integer> project,Statement st, int update, int sid) throws SQLException {
		int Testweights = 40;
		int Quizweights = 20;
		int Labweights = 10;
		int Projectweights = 30;
		
		float[] tot1 = new float[test.size()];
		float[] tot2 = new float[quiz.size()];
		float[] tot3 = new float[lab.size()];
		float[] tot4 = new float[project.size()];
		float[] overallRating = new float[10];
		int j = 0;
		float percentage = 0;
		
		//Test Score
		int TestscoreSize = test.size();
		for(int i=0; i<TestscoreSize; i++) {
			int marks = test.get(i);
			tot1[i] = (Testweights/TestscoreSize)*marks;
		}
		float Testsum = 0;
		for(int k=0; k<tot1.length;k++) {
			Testsum = Testsum + tot1[k];
		}
		float testFinalSum = Testsum/100;
		overallRating[j] = testFinalSum;
		j++;
		
		//Quiz Score
		int quizscoreSize = quiz.size();
		for(int i=0; i<quizscoreSize; i++) {
			int marks = quiz.get(i);
			tot2[i] = (Quizweights/quizscoreSize)*marks;
		}
		float quizsum = 0;
		for(int k=0; k<tot2.length;k++) {
			quizsum = quizsum + tot2[k];
		}
		float quizFinalSum = quizsum/100;
		overallRating[j] = quizFinalSum;
		j++;

		//Lab Score
		int labscoreSize = lab.size();
		for(int i=0; i<labscoreSize; i++) {
			int marks = lab.get(i);
			tot3[i] = (Labweights/labscoreSize)*marks;
		}
		float labsum = 0;
		for(int k=0; k<tot3.length;k++) {
			labsum = labsum + tot3[k];
		}
		float labFinalSum = labsum/100;
		overallRating[j] = labFinalSum;
		j++;
		
		//Project Score
		int projectscoreSize = project.size();
		for(int i=0; i<projectscoreSize; i++) {
			int marks = project.get(i);
			tot4[i] = (Projectweights/projectscoreSize)*marks;
		}
		float projectsum = 0;
		for(int k=0; k<tot4.length;k++) {
			projectsum = projectsum + tot4[k];
		}
		float projectFinalSum = projectsum/100;
		overallRating[j] = projectFinalSum;
		j++;
		
		subject = "Computing Techniques";
		
		percentage = calOverAll(overallRating);
		
		if(update == 0 && sid == 0) {
			String insertQuery = "insert into student(id,name,subject,Ttest,Tquiz,Tlab,Tproject,percentage) values ("+sID+",'"+snam+"','"+subject+"',"+testFinalSum+","+quizFinalSum+","+labFinalSum+","+projectFinalSum+","+percentage+")";
			st.executeUpdate(insertQuery);
		}
		if(update == 1) {
			String updateQuery = "update student set name = '"+snam+"', Ttest = "+testFinalSum+",Tquiz = "+quizFinalSum+",Tlab = "+labFinalSum+", "
					+ "Tproject = "+quizFinalSum+",percentage = "+percentage+" WHERE id = "+sid+" and subject = 'Computing Techniques'";
			st.executeUpdate(updateQuery);
		}
		}
	
	
	private static float calOverAll(float[] overallRating) {
		float overAllTotal = 0;
		for(int i=0;i<4;i++) {
			overAllTotal = overAllTotal + overallRating[i];
		}
		return overAllTotal;
	}
	
	private static void displayCollection(Statement st) throws SQLException {
			String displayQuery	= "select * from student";
			ResultSet rs = st.executeQuery(displayQuery);
			while(rs.next()) {
				int id = rs.getInt(1);
				String name = rs.getString("name");
				String subject = rs.getString("subject");
				float Ttest = rs.getFloat(4);
				float Tquiz = rs.getFloat(5);
				float Tlab = rs.getFloat(6);
				float Tproject = rs.getFloat(7);
				float percentage = rs.getFloat(8);
				System.out.println(id+" | "+name+" | "+subject+" | "+Ttest+" | "+Tquiz+" | "+Tlab+" | "+Tproject+" | "+percentage);
			}
		}
	
	private static void searchByID(Statement st, int stuID) throws SQLException {
		String searchIdQuery = "select * from student where id = "+stuID+"";
		ResultSet rs = st.executeQuery(searchIdQuery);
		while(rs.next()) {
			int id = rs.getInt(1);
			String name = rs.getString("name");
			String subject = rs.getString("subject");
			float Ttest = rs.getFloat(4);
			float Tquiz = rs.getFloat(5);
			float Tlab = rs.getFloat(6);
			float Tproject = rs.getFloat(7);
			float percentage = rs.getFloat(8);
			System.out.println(id+" | "+name+" | "+subject+" | "+Ttest+" | "+Tquiz+" | "+Tlab+" | "+Tproject+" | "+percentage);
		}
			
		}
	
	private static void searchBySubject(Statement st, String subNam) throws SQLException {
		String searchSubQuery	= "select * from student where subject = '"+subNam+"'";
		ResultSet rs = st.executeQuery(searchSubQuery);
		while(rs.next()) {
			int id = rs.getInt(1);
			String name = rs.getString("name");
			String subject = rs.getString("subject");
			float Ttest = rs.getFloat(4);
			float Tquiz = rs.getFloat(5);
			float Tlab = rs.getFloat(6);
			float Tproject = rs.getFloat(7);
			float percentage = rs.getFloat(8);
			System.out.println(id+" | "+name+" | "+subject+" | "+Ttest+" | "+Tquiz+" | "+Tlab+" | "+Tproject+" | "+percentage);
		}
		
	}
	
	private static void deleteByID(Statement st, int stuID) throws SQLException {
		String deleteIdQuery = "delete from student where id = "+stuID+"";
		st.executeUpdate(deleteIdQuery);
	}
	
	private static void deleteAll(Statement st) throws SQLException {
		String deleteIdQuery = "TRUNCATE TABLE student;";
		st.executeUpdate(deleteIdQuery);
	}
}


